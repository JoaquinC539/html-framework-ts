import { CustomElement } from "../utils/CustomElement";
import { ButtonComponent } from "./ButtonComponent";
import template from "./ButtonComponent2.html";
@CustomElement("button-component2")
export class ButtonComponent2 extends ButtonComponent{
    protected getTemplate(): string {
        return template;
    }
    protected script(): void {
        super.script();       
    }

    protected handleClick(event:MouseEvent):void{
        console.log("ButtonComponent2: button clicked");
        alert("ButtonComponent2 custom behavior!");
        const pelement=document.getElementById("display2");
        if(pelement!==null){
            pelement.innerText="You now clicked the second button";
        } 
    }
}