import { BaseComponent } from "../../abstract/BaseComponent";
import { Router } from "../../Router";
import { CustomElement } from "../../utils/CustomElement";
import template from './EditPage.html'
@CustomElement("edit-page")
export class HomePage extends BaseComponent{
    protected getTemplate(): string {
        return template;
    }
    protected script(): void {
        const params=Router.getParams();
        const editSpan=document.getElementById("editValue")
        editSpan!.textContent=params["id"]
        
    }
}
//  customElements.define("edit-page",HomePage); You can use this at the end of the line to export the tag if not using TS