import { BaseComponent } from "../../abstract/BaseComponent";
import tempate from "./index.html";
import { CustomElement } from "../../utils/CustomElement";
import "../../demoComponents/ButtonComponent"
import "../../demoComponents/ButtonComponent2"

@CustomElement("about-page")
export class AboutPage extends BaseComponent{
    protected getTemplate(): string {
        return tempate
    }
    protected script(): void {   
        
    }
}
